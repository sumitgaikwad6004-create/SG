export interface ExtractedFile {
  path: string;
  isText: boolean;
  content: string; // utf-8 text or base64 binary
  size: number;
}

export interface AndroidProjectMetadata {
  projectName: string;
  applicationId: string;
  namespace?: string;
  minSdk?: number;
  targetSdk?: number;
  compileSdk?: number;
  versionCode?: number;
  versionName?: string;
  gradleVersion?: string;
  agpVersion?: string;
  kotlinVersion?: string;
  recommendedJavaVersion: '11' | '17' | '21';
  hasGradleWrapper: boolean;
  modules: string[];
  mainModule: string;
  buildFilesFound: {
    settingsGradle: boolean;
    rootBuildGradle: boolean;
    appBuildGradle: boolean;
    gradleWrapperProperties: boolean;
    androidManifest: boolean;
  };
  totalFiles: number;
  totalSize: number;
  warnings: string[];
}

export type BuildVariant = 'debug' | 'release';

export interface SigningConfig {
  keystoreBase64: string;
  storePassword: string;
  keyAlias: string;
  keyPassword: string;
}

export type BuildStatus = 'IDLE' | 'ANALYZING' | 'WAITING' | 'QUEUED' | 'BUILDING' | 'SUCCESS' | 'FAILED';

export interface BuildRecord {
  id: string;
  projectName: string;
  applicationId: string;
  repoOwner: string;
  repoName: string;
  runId: number;
  buildNumber: number;
  status: BuildStatus;
  buildVariant: BuildVariant;
  startTime: string;
  endTime?: string;
  durationSeconds?: number;
  apkName?: string;
  apkSize?: number;
  artifactId?: number;
  commitSha?: string;
  htmlUrl?: string;
  errorMessage?: string;
}
