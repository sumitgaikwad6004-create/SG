import type { BuildRecord } from '../types/project';

const HISTORY_STORAGE_KEY = 'sg_zip_to_apk_history';

export function getBuildHistory(): BuildRecord[] {
  try {
    const raw = localStorage.getItem(HISTORY_STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (err) {
    console.error('Failed to read build history:', err);
    return [];
  }
}

export function saveBuildRecord(record: BuildRecord): void {
  try {
    const history = getBuildHistory();
    const existingIndex = history.findIndex((h) => h.id === record.id);
    if (existingIndex >= 0) {
      history[existingIndex] = record;
    } else {
      history.unshift(record);
    }
    // Keep last 50 builds
    const trimmed = history.slice(0, 50);
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(trimmed));
  } catch (err) {
    console.error('Failed to save build record:', err);
  }
}

export function deleteBuildRecord(id: string): void {
  try {
    const history = getBuildHistory().filter((h) => h.id !== id);
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(history));
  } catch (err) {
    console.error('Failed to delete build record:', err);
  }
}

export function clearBuildHistory(): void {
  try {
    localStorage.removeItem(HISTORY_STORAGE_KEY);
  } catch (err) {
    console.error('Failed to clear build history:', err);
  }
}
