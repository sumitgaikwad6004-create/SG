import type {
  GitHubArtifact,
  GitHubJob,
  GitHubRateLimit,
  GitHubRepo,
  GitHubUser,
  GitHubWorkflowRun,
} from '../types/github';
import type { ExtractedFile } from '../types/project';

const GITHUB_API_BASE = 'https://api.github.com';
const TOKEN_STORAGE_KEY = 'sg_zip_to_apk_gh_token';

export function getStoredGitHubToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_STORAGE_KEY);
  } catch {
    return null;
  }
}

export function setStoredGitHubToken(token: string | null): void {
  try {
    if (token) {
      localStorage.setItem(TOKEN_STORAGE_KEY, token.trim());
    } else {
      localStorage.removeItem(TOKEN_STORAGE_KEY);
    }
  } catch (err) {
    console.error('Failed to access localStorage:', err);
  }
}

async function githubFetch<T>(
  endpoint: string,
  token: string,
  options: RequestInit = {}
): Promise<T> {
  const url = endpoint.startsWith('http') ? endpoint : `${GITHUB_API_BASE}${endpoint}`;
  const headers = new Headers(options.headers || {});
  headers.set('Authorization', `Bearer ${token.trim()}`);
  headers.set('Accept', 'application/vnd.github+json');
  headers.set('X-GitHub-Api-Version', '2022-11-28');
  if (options.body && typeof options.body === 'string' && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }

  const res = await fetch(url, { ...options, headers });

  if (res.status === 204) {
    return {} as T;
  }

  if (!res.ok) {
    let errorDetail = res.statusText;
    try {
      const json = await res.json();
      errorDetail = json.message || JSON.stringify(json);
    } catch {
      // ignore
    }
    throw new Error(`GitHub API Error (${res.status}): ${errorDetail}`);
  }

  return (await res.json()) as T;
}

/**
 * Validate token and retrieve the authenticated user profile.
 */
export async function getAuthenticatedUser(token: string): Promise<GitHubUser> {
  return await githubFetch<GitHubUser>('/user', token);
}

/**
 * Check rate limit status.
 */
export async function getRateLimit(token: string): Promise<GitHubRateLimit> {
  const data = await githubFetch<{ resources: { core: GitHubRateLimit } }>('/rate_limit', token);
  return data.resources.core;
}

/**
 * List the authenticated user's repositories.
 */
export async function listUserRepositories(token: string): Promise<GitHubRepo[]> {
  return await githubFetch<GitHubRepo[]>(
    '/user/repos?sort=updated&per_page=30&affiliation=owner,collaborator',
    token
  );
}

/**
 * Create a new repository for the user.
 */
export async function createRepository(
  token: string,
  name: string,
  isPrivate: boolean = true,
  description: string = 'Created with SG ZIP TO APK PRO'
): Promise<GitHubRepo> {
  return await githubFetch<GitHubRepo>('/user/repos', token, {
    method: 'POST',
    body: JSON.stringify({
      name,
      private: isPrivate,
      description,
      auto_init: true, // creates default branch with README
    }),
  });
}

/**
 * Atomically uploads all project files (including .github/workflows/build.yml)
 * to the specified GitHub repository using the Git Data API (Blobs -> Tree -> Commit -> Ref).
 */
export async function uploadProjectFiles(
  token: string,
  owner: string,
  repo: string,
  branch: string,
  files: ExtractedFile[],
  workflowContent: string,
  onProgress?: (progress: { stage: string; current: number; total: number }) => void
): Promise<{ commitSha: string }> {
  // 1. Prepare files list, including the GitHub Actions workflow file
  const allFiles: ExtractedFile[] = [
    ...files,
    {
      path: '.github/workflows/build.yml',
      isText: true,
      content: workflowContent,
      size: workflowContent.length,
    },
  ];

  // 2. Fetch latest commit SHA on the branch (if repo already initialized)
  let parentCommitSha: string | null = null;
  let baseTreeSha: string | null = null;

  try {
    const refData = await githubFetch<{ object: { sha: string } }>(
      `/repos/${owner}/${repo}/git/ref/heads/${branch}`,
      token
    );
    parentCommitSha = refData.object.sha;

    const commitData = await githubFetch<{ tree: { sha: string } }>(
      `/repos/${owner}/${repo}/git/commits/${parentCommitSha}`,
      token
    );
    baseTreeSha = commitData.tree.sha;
  } catch (err) {
    // If branch doesn't exist, check default repo branch
    try {
      const repoData = await githubFetch<GitHubRepo>(`/repos/${owner}/${repo}`, token);
      const defaultBranch = repoData.default_branch || 'main';
      const refData = await githubFetch<{ object: { sha: string } }>(
        `/repos/${owner}/${repo}/git/ref/heads/${defaultBranch}`,
        token
      );
      parentCommitSha = refData.object.sha;
    } catch {
      // Empty repo without commits
    }
  }

  // 3. Create Blobs in parallel batches to respect rate limits
  const BATCH_SIZE = 10;
  const treeItems: Array<{ path: string; mode: '100644' | '100755'; type: 'blob'; sha: string }> =
    [];

  for (let i = 0; i < allFiles.length; i += BATCH_SIZE) {
    const batch = allFiles.slice(i, i + BATCH_SIZE);
    onProgress?.({
      stage: 'Uploading project files to GitHub',
      current: Math.min(i + BATCH_SIZE, allFiles.length),
      total: allFiles.length,
    });

    const blobPromises = batch.map(async (file) => {
      const blobRes = await githubFetch<{ sha: string }>(
        `/repos/${owner}/${repo}/git/blobs`,
        token,
        {
          method: 'POST',
          body: JSON.stringify({
            content: file.content,
            encoding: file.isText ? 'utf-8' : 'base64',
          }),
        }
      );

      // Executable mode 100755 for gradlew, 100644 for others
      const mode: '100644' | '100755' = file.path === 'gradlew' ? '100755' : '100644';

      return {
        path: file.path,
        mode,
        type: 'blob' as const,
        sha: blobRes.sha,
      };
    });

    const batchResults = await Promise.all(blobPromises);
    treeItems.push(...batchResults);
  }

  // 4. Create Git Tree
  onProgress?.({
    stage: 'Creating Git tree',
    current: allFiles.length,
    total: allFiles.length,
  });

  const treePayload: { tree: typeof treeItems; base_tree?: string } = {
    tree: treeItems,
  };
  if (baseTreeSha) {
    treePayload.base_tree = baseTreeSha;
  }

  const treeRes = await githubFetch<{ sha: string }>(
    `/repos/${owner}/${repo}/git/trees`,
    token,
    {
      method: 'POST',
      body: JSON.stringify(treePayload),
    }
  );

  // 5. Create Git Commit
  onProgress?.({
    stage: 'Creating Git commit',
    current: allFiles.length,
    total: allFiles.length,
  });

  const commitPayload: {
    message: string;
    tree: string;
    parents: string[];
  } = {
    message: 'Compile Android APK via SG ZIP TO APK PRO',
    tree: treeRes.sha,
    parents: parentCommitSha ? [parentCommitSha] : [],
  };

  const commitRes = await githubFetch<{ sha: string }>(
    `/repos/${owner}/${repo}/git/commits`,
    token,
    {
      method: 'POST',
      body: JSON.stringify(commitPayload),
    }
  );

  // 6. Update or Create Ref
  onProgress?.({
    stage: 'Updating branch reference',
    current: allFiles.length,
    total: allFiles.length,
  });

  if (parentCommitSha) {
    await githubFetch(`/repos/${owner}/${repo}/git/refs/heads/${branch}`, token, {
      method: 'PATCH',
      body: JSON.stringify({
        sha: commitRes.sha,
        force: true,
      }),
    });
  } else {
    try {
      await githubFetch(`/repos/${owner}/${repo}/git/refs`, token, {
        method: 'POST',
        body: JSON.stringify({
          ref: `refs/heads/${branch}`,
          sha: commitRes.sha,
        }),
      });
    } catch {
      // If ref creation failed because it was created in the interim, patch it
      await githubFetch(`/repos/${owner}/${repo}/git/refs/heads/${branch}`, token, {
        method: 'PATCH',
        body: JSON.stringify({
          sha: commitRes.sha,
          force: true,
        }),
      });
    }
  }

  return { commitSha: commitRes.sha };
}

/**
 * Triggers the GitHub Actions workflow manually via workflow_dispatch.
 */
export async function triggerWorkflowDispatch(
  token: string,
  owner: string,
  repo: string,
  workflowFileName: string = 'build.yml',
  branch: string = 'main',
  inputs: Record<string, string> = { build_type: 'debug' }
): Promise<void> {
  await githubFetch(
    `/repos/${owner}/${repo}/actions/workflows/${workflowFileName}/dispatches`,
    token,
    {
      method: 'POST',
      body: JSON.stringify({
        ref: branch,
        inputs,
      }),
    }
  );
}

/**
 * Retrieve recent workflow runs for the repository.
 */
export async function getWorkflowRuns(
  token: string,
  owner: string,
  repo: string,
  branch?: string
): Promise<GitHubWorkflowRun[]> {
  const branchParam = branch ? `&branch=${branch}` : '';
  const data = await githubFetch<{ workflow_runs: GitHubWorkflowRun[] }>(
    `/repos/${owner}/${repo}/actions/runs?per_page=10${branchParam}`,
    token
  );
  return data.workflow_runs || [];
}

/**
 * Retrieve a specific workflow run.
 */
export async function getWorkflowRun(
  token: string,
  owner: string,
  repo: string,
  runId: number
): Promise<GitHubWorkflowRun> {
  return await githubFetch<GitHubWorkflowRun>(
    `/repos/${owner}/${repo}/actions/runs/${runId}`,
    token
  );
}

/**
 * Retrieve jobs and their execution steps for a workflow run.
 */
export async function getRunJobs(
  token: string,
  owner: string,
  repo: string,
  runId: number
): Promise<GitHubJob[]> {
  const data = await githubFetch<{ jobs: GitHubJob[] }>(
    `/repos/${owner}/${repo}/actions/runs/${runId}/jobs`,
    token
  );
  return data.jobs || [];
}

/**
 * Retrieve raw build logs for a job.
 */
export async function getJobLogs(
  token: string,
  owner: string,
  repo: string,
  jobId: number
): Promise<string> {
  const url = `${GITHUB_API_BASE}/repos/${owner}/${repo}/actions/jobs/${jobId}/logs`;
  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${token.trim()}`,
      Accept: 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
    },
  });

  if (!res.ok) {
    if (res.status === 404) {
      return 'Build logs are not ready yet or are currently streaming...';
    }
    throw new Error(`Failed to load job logs: ${res.statusText}`);
  }

  return await res.text();
}

/**
 * Retrieve artifacts produced by a workflow run.
 */
export async function getRunArtifacts(
  token: string,
  owner: string,
  repo: string,
  runId: number
): Promise<GitHubArtifact[]> {
  const data = await githubFetch<{ artifacts: GitHubArtifact[] }>(
    `/repos/${owner}/${repo}/actions/runs/${runId}/artifacts`,
    token
  );
  return data.artifacts || [];
}

/**
 * Download APK file using the server-side proxy which automatically unpacks the
 * GitHub artifact ZIP and streams the installable .apk directly to the client.
 */
export async function downloadApkFromProxy(
  token: string,
  owner: string,
  repo: string,
  artifactId: number,
  apkName: string = 'app-debug.apk'
): Promise<Blob> {
  const url = `/api/download-apk?owner=${encodeURIComponent(owner)}&repo=${encodeURIComponent(
    repo
  )}&artifactId=${artifactId}&apkName=${encodeURIComponent(apkName)}`;

  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${token.trim()}`,
    },
  });

  if (!res.ok) {
    let errMessage = res.statusText;
    try {
      const errJson = await res.json();
      errMessage = errJson.error || errMessage;
    } catch {
      // ignore
    }
    throw new Error(`Failed to download APK: ${errMessage}`);
  }

  return await res.blob();
}
