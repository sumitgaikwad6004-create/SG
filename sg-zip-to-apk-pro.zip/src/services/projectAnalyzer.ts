import JSZip from 'jszip';
import type { AndroidProjectMetadata, ExtractedFile } from '../types/project';

const MAX_ZIP_SIZE = 250 * 1024 * 1024; // 250 MB
const MAX_TOTAL_UNCOMPRESSED_SIZE = 600 * 1024 * 1024; // 600 MB
const MAX_FILE_COUNT = 8000;

// Binary file extensions that should be stored as base64
const BINARY_EXTENSIONS = new Set([
  'png', 'jpg', 'jpeg', 'gif', 'webp', 'ico', 'svgz',
  'jar', 'aar', 'so', 'zip', 'tar', 'gz',
  'keystore', 'jks', 'bin', 'class', 'dex',
  'ttf', 'otf', 'woff', 'woff2',
  'mp3', 'ogg', 'wav', 'mp4',
]);

function isBinaryFile(filePath: string): boolean {
  const ext = filePath.split('.').pop()?.toLowerCase();
  return ext ? BINARY_EXTENSIONS.has(ext) : false;
}

export class ZipSecurityError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ZipSecurityError';
  }
}

/**
 * Validates, sanitizes, and analyzes an Android Studio Project ZIP file.
 */
export async function analyzeAndroidZip(file: File | Blob): Promise<{
  metadata: AndroidProjectMetadata;
  files: ExtractedFile[];
}> {
  if (file.size > MAX_ZIP_SIZE) {
    throw new ZipSecurityError(
      `File size (${(file.size / (1024 * 1024)).toFixed(1)} MB) exceeds maximum allowed size of 250 MB.`
    );
  }

  const arrayBuffer = await file.arrayBuffer();
  let zip: JSZip;
  try {
    zip = await JSZip.loadAsync(arrayBuffer);
  } catch (err) {
    throw new ZipSecurityError(
      'Invalid or corrupted ZIP archive. Please ensure your project is properly compressed.'
    );
  }

  // 1. Path Traversal & Security Validation
  let totalFiles = 0;
  let totalUncompressedSize = 0;
  const rawPaths: string[] = [];

  zip.forEach((relativePath, zipEntry) => {
    // Check path traversal attempts
    const normalized = relativePath.replace(/\\/g, '/');
    if (
      normalized.includes('../') ||
      normalized.includes('..\\') ||
      normalized.startsWith('/') ||
      normalized.includes('\0')
    ) {
      throw new ZipSecurityError(
        `Malicious path detected in archive: "${relativePath}". Archive contains directory traversal entries.`
      );
    }

    if (!zipEntry.dir) {
      totalFiles++;
      rawPaths.push(normalized);
      // Rough size accumulation
      const uncompressedSize = (zipEntry as unknown as { _data?: { uncompressedSize?: number } })._data?.uncompressedSize || 0;
      totalUncompressedSize += uncompressedSize;
    }
  });

  if (totalFiles === 0) {
    throw new ZipSecurityError('The uploaded ZIP archive is empty.');
  }

  if (totalFiles > MAX_FILE_COUNT) {
    throw new ZipSecurityError(
      `Archive contains ${totalFiles} files, exceeding the limit of ${MAX_FILE_COUNT}. Please clean build directories (.gradle, build) before zipping.`
    );
  }

  if (totalUncompressedSize > MAX_TOTAL_UNCOMPRESSED_SIZE) {
    throw new ZipSecurityError(
      `Archive uncompressed size is too large (${(totalUncompressedSize / (1024 * 1024)).toFixed(1)} MB). Exceeds 600 MB limit.`
    );
  }

  // 2. Detect common root folder (e.g., if user zipped a folder named 'MyApplication')
  let commonPrefix = '';
  const firstPathParts = rawPaths[0].split('/');
  if (firstPathParts.length > 1) {
    const candidate = firstPathParts[0] + '/';
    const allHaveCandidate = rawPaths.every((p) => p.startsWith(candidate));
    if (allHaveCandidate) {
      commonPrefix = candidate;
    }
  }

  // 3. Extract and filter files, skipping junk (.DS_Store, build cache, .gradle)
  const extractedFiles: ExtractedFile[] = [];
  const warnings: string[] = [];

  const ignoredFolders = [
    '.gradle/',
    'build/',
    'app/build/',
    '.idea/',
    '.git/',
    '__MACOSX/',
  ];

  for (const rawPath of rawPaths) {
    const cleanPath = commonPrefix ? rawPath.slice(commonPrefix.length) : rawPath;

    // Skip Mac metadata or build artifacts
    if (
      cleanPath.startsWith('__MACOSX/') ||
      cleanPath.endsWith('.DS_Store') ||
      cleanPath.endsWith('Thumbs.db')
    ) {
      continue;
    }

    // Skip build folders that add bloat and break builds on CI
    if (ignoredFolders.some((f) => cleanPath.startsWith(f) || cleanPath.includes('/build/'))) {
      continue;
    }

    const zipEntry = zip.file(rawPath);
    if (!zipEntry) continue;

    const isBinary = isBinaryFile(cleanPath);
    let content = '';
    let size = 0;

    if (isBinary) {
      const base64 = await zipEntry.async('base64');
      content = base64;
      size = Math.round((base64.length * 3) / 4);
    } else {
      content = await zipEntry.async('string');
      size = content.length;
    }

    extractedFiles.push({
      path: cleanPath,
      isText: !isBinary,
      content,
      size,
    });
  }

  // 4. Analyze Android Project Structure
  let projectName = 'AndroidApp';
  let applicationId = 'com.example.app';
  let namespace: string | undefined;
  let minSdk: number | undefined;
  let targetSdk: number | undefined;
  let compileSdk: number | undefined;
  let versionCode: number | undefined;
  let versionName: string | undefined;
  let gradleVersion: string | undefined;
  let agpVersion: string | undefined;
  let kotlinVersion: string | undefined;
  let jvmVersionDetected: string | undefined;
  let hasGradleWrapper = false;
  const modules: string[] = [];

  const buildFilesFound = {
    settingsGradle: false,
    rootBuildGradle: false,
    appBuildGradle: false,
    gradleWrapperProperties: false,
    androidManifest: false,
  };

  for (const file of extractedFiles) {
    const p = file.path;

    // Check gradlew
    if (p === 'gradlew' || p === 'gradlew.bat') {
      hasGradleWrapper = true;
    }

    // Parse gradle-wrapper.properties
    if (p.includes('gradle-wrapper.properties')) {
      buildFilesFound.gradleWrapperProperties = true;
      const match = file.content.match(/gradle-([0-9.]+)-/);
      if (match) {
        gradleVersion = match[1];
      }
    }

    // Parse settings.gradle or settings.gradle.kts
    if (p === 'settings.gradle' || p === 'settings.gradle.kts') {
      buildFilesFound.settingsGradle = true;
      const rootMatch = file.content.match(/rootProject\.name\s*=\s*['"]([^'"]+)['"]/);
      if (rootMatch) {
        projectName = rootMatch[1].trim();
      }

      // Check modules: include ':app', ':core' or include(":app")
      const includeMatches = file.content.matchAll(/include\s*\(?['":]([^'")\s,]+)['"]?\)?/g);
      for (const m of includeMatches) {
        const modName = m[1].replace(/^:/, '');
        if (modName && !modules.includes(modName)) {
          modules.push(modName);
        }
      }
    }

    // Parse top-level build.gradle or build.gradle.kts
    if (p === 'build.gradle' || p === 'build.gradle.kts') {
      buildFilesFound.rootBuildGradle = true;
      // Detect AGP in plugins or dependencies
      const agpMatch =
        file.content.match(/id\s*\(?['"]com\.android\.application['"]\)?\s*version\s*['"]([^'"]+)['"]/) ||
        file.content.match(/['"]com\.android\.tools\.build:gradle:([^'"]+)['"]/);
      if (agpMatch) {
        agpVersion = agpMatch[1];
      }

      // Detect Kotlin version
      const kotlinMatch =
        file.content.match(/id\s*\(?['"]org\.jetbrains\.kotlin\.android['"]\)?\s*version\s*['"]([^'"]+)['"]/) ||
        file.content.match(/['"]org\.jetbrains\.kotlin:kotlin-gradle-plugin:([^'"]+)['"]/);
      if (kotlinMatch) {
        kotlinVersion = kotlinMatch[1];
      }
    }

    // Parse app module build.gradle
    if (
      p.endsWith('build.gradle') ||
      p.endsWith('build.gradle.kts') ||
      p.includes('/build.gradle')
    ) {
      if (p.includes('app/') || p.includes('app\\') || (!buildFilesFound.appBuildGradle && p !== 'build.gradle')) {
        buildFilesFound.appBuildGradle = true;

        // Namespace
        const nsMatch = file.content.match(/namespace\s*=?\s*['"]([^'"]+)['"]/);
        if (nsMatch) namespace = nsMatch[1];

        // ApplicationId
        const appIdMatch = file.content.match(/applicationId\s*=?\s*['"]([^'"]+)['"]/);
        if (appIdMatch) applicationId = appIdMatch[1];

        // CompileSdk
        const compileSdkMatch =
          file.content.match(/compileSdk\s*=?\s*(\d+)/) ||
          file.content.match(/compileSdkVersion\s*=?\s*(\d+)/);
        if (compileSdkMatch) compileSdk = parseInt(compileSdkMatch[1], 10);

        // MinSdk
        const minSdkMatch =
          file.content.match(/minSdk\s*=?\s*(\d+)/) ||
          file.content.match(/minSdkVersion\s*=?\s*(\d+)/);
        if (minSdkMatch) minSdk = parseInt(minSdkMatch[1], 10);

        // TargetSdk
        const targetSdkMatch =
          file.content.match(/targetSdk\s*=?\s*(\d+)/) ||
          file.content.match(/targetSdkVersion\s*=?\s*(\d+)/);
        if (targetSdkMatch) targetSdk = parseInt(targetSdkMatch[1], 10);

        // VersionCode
        const vcMatch = file.content.match(/versionCode\s*=?\s*(\d+)/);
        if (vcMatch) versionCode = parseInt(vcMatch[1], 10);

        // VersionName
        const vnMatch = file.content.match(/versionName\s*=?\s*['"]([^'"]+)['"]/);
        if (vnMatch) versionName = vnMatch[1];

        // JVM Target / Java Version
        const jvmMatch =
          file.content.match(/jvmTarget\s*=?\s*['"]?(\d+)['"]?/) ||
          file.content.match(/JavaVersion\.VERSION_(\d+)/);
        if (jvmMatch) jvmVersionDetected = jvmMatch[1];
      }
    }

    // AndroidManifest.xml
    if (p.endsWith('AndroidManifest.xml')) {
      buildFilesFound.androidManifest = true;
      if (!applicationId || applicationId === 'com.example.app') {
        const pkgMatch = file.content.match(/package\s*=\s*['"]([^'"]+)['"]/);
        if (pkgMatch) {
          applicationId = pkgMatch[1];
        }
      }
    }
  }

  if (namespace && (!applicationId || applicationId === 'com.example.app')) {
    applicationId = namespace;
  }

  if (modules.length === 0) {
    modules.push('app');
  }

  // 5. Intelligent Java Compatibility Resolution
  // Gradle 8.x + AGP 8.x requires Java 17 minimum.
  // AGP 8.4+ supports Java 21.
  // AGP 7.x supports Java 11 or 17.
  // AGP 4.x/3.x needs Java 8 or 11.
  let recommendedJavaVersion: '11' | '17' | '21' = '17';

  if (agpVersion) {
    const agpMajor = parseFloat(agpVersion);
    if (agpMajor >= 8.4) {
      recommendedJavaVersion = '17'; // Temurin 17 is most universally stable for AGP 8.x
    } else if (agpMajor >= 8.0) {
      recommendedJavaVersion = '17';
    } else if (agpMajor < 7.0) {
      recommendedJavaVersion = '11';
    }
  } else if (gradleVersion) {
    const gradleMajor = parseFloat(gradleVersion);
    if (gradleMajor < 7.0) {
      recommendedJavaVersion = '11';
    } else {
      recommendedJavaVersion = '17';
    }
  }

  if (jvmVersionDetected === '21') {
    recommendedJavaVersion = '21';
  } else if (jvmVersionDetected === '11' && (!agpVersion || parseFloat(agpVersion) < 8.0)) {
    recommendedJavaVersion = '11';
  }

  // 6. Validation and warnings
  if (!buildFilesFound.settingsGradle && !buildFilesFound.rootBuildGradle) {
    warnings.push(
      'Missing settings.gradle or root build.gradle file. Standard Android project structure could not be verified.'
    );
  }

  if (!hasGradleWrapper) {
    warnings.push(
      'Gradle wrapper (gradlew) is missing. The cloud compiler will automatically generate an optimized Gradle wrapper.'
    );
  }

  if (!buildFilesFound.androidManifest) {
    warnings.push('AndroidManifest.xml was not detected in typical location.');
  }

  const metadata: AndroidProjectMetadata = {
    projectName: projectName || 'AndroidApp',
    applicationId: applicationId || 'com.example.app',
    namespace,
    minSdk: minSdk || 24,
    targetSdk: targetSdk || 34,
    compileSdk: compileSdk || 34,
    versionCode: versionCode || 1,
    versionName: versionName || '1.0.0',
    gradleVersion: gradleVersion || '8.5',
    agpVersion: agpVersion || '8.2.2',
    kotlinVersion: kotlinVersion || '1.9.22',
    recommendedJavaVersion,
    hasGradleWrapper,
    modules,
    mainModule: modules[0] || 'app',
    buildFilesFound,
    totalFiles: extractedFiles.length,
    totalSize: extractedFiles.reduce((acc, f) => acc + f.size, 0),
    warnings,
  };

  return { metadata, files: extractedFiles };
}
