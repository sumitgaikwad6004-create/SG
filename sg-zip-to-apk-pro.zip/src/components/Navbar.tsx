import React from 'react';
import { Github, Sun, Moon, LogOut } from 'lucide-react';
import type { GitHubUser } from '../types/github';
import { PWAInstallButton } from './PWAInstallButton';

interface NavbarProps {
  activeTab: 'compiler' | 'history' | 'guide';
  setActiveTab: (tab: 'compiler' | 'history' | 'guide') => void;
  currentUser: GitHubUser | null;
  onOpenConnect: () => void;
  onDisconnect: () => void;
  isDark: boolean;
  onToggleTheme: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  currentUser,
  onOpenConnect,
  onDisconnect,
  isDark,
  onToggleTheme,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full bg-slate-900/90 dark:bg-slate-950/90 backdrop-blur-md border-b border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4 md:gap-8">
        {/* Zone 1: Single text element Brand wordmark */}
        <button
          onClick={() => setActiveTab('compiler')}
          className="text-left flex items-center gap-2.5 focus:outline-none"
        >
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center shrink-0">
            <span className="text-emerald-400 font-bold text-sm">SG</span>
          </div>
          <span className="text-base sm:text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0">
            SG ZIP TO APK PRO
          </span>
        </button>

        {/* Zone 2: Concise single-line navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
          <button
            onClick={() => setActiveTab('compiler')}
            className={`transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'compiler' ? 'text-emerald-400' : 'hover:text-slate-200'
            }`}
          >
            Compiler
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'history' ? 'text-emerald-400' : 'hover:text-slate-200'
            }`}
          >
            Build History
          </button>
          <button
            onClick={() => setActiveTab('guide')}
            className={`transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'guide' ? 'text-emerald-400' : 'hover:text-slate-200'
            }`}
          >
            Android Guide
          </button>
          <a
            href="https://github.com"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-slate-200 transition-colors whitespace-nowrap shrink-0"
          >
            GitHub Cloud
          </a>
        </nav>

        {/* Zone 3: 1 primary action or connection button */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          <PWAInstallButton />

          <button
            onClick={onToggleTheme}
            className="p-2 text-slate-400 hover:text-slate-200 rounded-lg hover:bg-slate-800/80 transition-colors"
            title={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
            aria-label="Toggle Theme"
          >
            {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          {currentUser ? (
            <div className="flex items-center gap-2 bg-slate-800/80 border border-slate-700/80 pl-2 pr-1 py-1 rounded-xl">
              <img
                src={currentUser.avatar_url}
                alt={currentUser.login}
                referrerPolicy="no-referrer"
                className="w-6 h-6 rounded-full object-cover border border-slate-600"
              />
              <span className="text-xs font-medium text-slate-200 max-w-[90px] sm:max-w-[120px] truncate">
                {currentUser.login}
              </span>
              <button
                onClick={onDisconnect}
                className="p-1 text-slate-400 hover:text-red-400 rounded-lg hover:bg-slate-700/60 transition-colors"
                title="Disconnect GitHub account"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenConnect}
              className="flex items-center gap-2 px-3.5 py-1.5 text-xs sm:text-sm font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-xl transition-colors whitespace-nowrap shadow-sm shadow-emerald-950/20"
            >
              <Github className="w-4 h-4" />
              <span>Connect GitHub</span>
            </button>
          )}
        </div>
      </div>

      {/* Mobile Sub-Navigation Bar */}
      <div className="md:hidden flex items-center justify-around px-4 py-2 border-t border-slate-800/60 bg-slate-950/60 text-xs font-medium text-slate-400">
        <button
          onClick={() => setActiveTab('compiler')}
          className={`py-1 ${activeTab === 'compiler' ? 'text-emerald-400 font-semibold' : ''}`}
        >
          Compiler
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`py-1 ${activeTab === 'history' ? 'text-emerald-400 font-semibold' : ''}`}
        >
          History
        </button>
        <button
          onClick={() => setActiveTab('guide')}
          className={`py-1 ${activeTab === 'guide' ? 'text-emerald-400 font-semibold' : ''}`}
        >
          Android Guide
        </button>
      </div>
    </header>
  );
};
