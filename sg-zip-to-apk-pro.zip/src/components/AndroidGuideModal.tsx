import React from 'react';
import {
  Smartphone,
  Key,
  Download,
  ShieldCheck,
  CheckCircle2,
  ExternalLink,
  HelpCircle,
  FileArchive,
  Terminal,
} from 'lucide-react';

export const AndroidGuideModal: React.FC = () => {
  const tokenUrl =
    'https://github.com/settings/tokens/new?scopes=repo,workflow&description=SG+ZIP+TO+APK+PRO';

  return (
    <div className="w-full max-w-4xl mx-auto space-y-8">
      {/* Hero */}
      <div className="rounded-3xl bg-slate-900 border border-slate-800 p-6 sm:p-8 space-y-3">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-white">
              Android-Only Mobile Compilation Guide
            </h1>
            <p className="text-xs sm:text-sm text-slate-400">
              Compile and install Android Studio APKs directly on your phone — no PC required.
            </p>
          </div>
        </div>
      </div>

      {/* 4-Step Walkthrough */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Step 1 */}
        <div className="p-5 sm:p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold text-xs flex items-center justify-center font-mono">
              01
            </div>
            <h3 className="text-base font-bold text-white">Create GitHub Token on Mobile</h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            GitHub Actions requires a Personal Access Token with two scopes to build your app in the cloud:
          </p>
          <div className="space-y-1.5 text-xs text-slate-400">
            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>repo</strong>: Allows uploading project files and workflow configuration.
              </span>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>workflow</strong>: Allows triggering the GitHub Actions compiler runner.
              </span>
            </div>
          </div>
          <a
            href={tokenUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-emerald-300 bg-emerald-950/50 border border-emerald-800/60 rounded-xl hover:bg-emerald-900/50 transition-colors"
          >
            <span>Open Pre-Filled Token Page</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>

        {/* Step 2 */}
        <div className="p-5 sm:p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold text-xs flex items-center justify-center font-mono">
              02
            </div>
            <h3 className="text-base font-bold text-white">Select Project ZIP on Phone</h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Download your Android Studio project or Git repository as a ZIP archive directly onto your phone:
          </p>
          <ul className="list-disc list-inside space-y-1 text-xs text-slate-400 pl-1">
            <li>Ensure <code>settings.gradle</code> or <code>build.gradle</code> is present.</li>
            <li>Our engine automatically removes unnecessary <code>.gradle/</code> cache folders.</li>
            <li>Missing <code>gradlew</code> wrappers are automatically generated.</li>
            <li>Or tap <strong>"Load Sample Android Project"</strong> to compile instantly!</li>
          </ul>
        </div>

        {/* Step 3 */}
        <div className="p-5 sm:p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold text-xs flex items-center justify-center font-mono">
              03
            </div>
            <h3 className="text-base font-bold text-white">Cloud Compilation in Action</h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            When you tap <strong>BUILD APK</strong>:
          </p>
          <ul className="list-disc list-inside space-y-1 text-xs text-slate-400 pl-1">
            <li>Files are pushed securely to your private GitHub repo.</li>
            <li>GitHub Actions launches a high-performance Ubuntu cloud runner.</li>
            <li>Gradle builds your APK with official Android SDK and Temurin JDK.</li>
            <li>Live step progress and terminal logs stream directly to your phone screen.</li>
          </ul>
        </div>

        {/* Step 4 */}
        <div className="p-5 sm:p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold text-xs flex items-center justify-center font-mono">
              04
            </div>
            <h3 className="text-base font-bold text-white">Installing APK on Android Phone</h3>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Once compiled, tap <strong>DOWNLOAD APK TO PHONE</strong>:
          </p>
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-[11px] text-slate-400 space-y-1.5">
            <span className="font-semibold text-slate-200">Enabling Unknown Sources on Android:</span>
            <p>1. Open phone <strong>Settings → Apps → Special app access</strong>.</p>
            <p>2. Tap <strong>Install unknown apps</strong>.</p>
            <p>3. Select your browser (Chrome/Edge/PWA) and toggle <strong>Allow from this source</strong>.</p>
            <p>4. Tap the downloaded <code>.apk</code> in your Notifications or Downloads folder to install.</p>
          </div>
        </div>
      </div>

      {/* Troubleshooting Section */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
        <div className="flex items-center gap-2">
          <HelpCircle className="w-5 h-5 text-emerald-400" />
          <h2 className="text-lg font-bold text-white">Troubleshooting Common Issues</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-1.5">
            <span className="font-semibold text-amber-300">
              "Zip bomb / archive too large" error:
            </span>
            <p className="text-slate-400 leading-relaxed">
              If your zip is over 250MB, it usually contains local build directories. Use a phone file manager (like ZArchiver) to delete <code>.gradle</code> and <code>build</code> folders before compressing.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-1.5">
            <span className="font-semibold text-amber-300">
              "Unsupported class file major version":
            </span>
            <p className="text-slate-400 leading-relaxed">
              Our analyzer automatically maps Gradle 8.x to Java 17 and AGP 7.x to Java 11. You can inspect and tweak the JDK version inside the workflow preview before starting compilation.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
