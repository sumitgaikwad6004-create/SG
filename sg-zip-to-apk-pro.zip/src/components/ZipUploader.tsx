import React, { useRef, useState } from 'react';
import { UploadCloud, FileArchive, Sparkles, AlertTriangle, ShieldCheck, Check } from 'lucide-react';
import { analyzeAndroidZip } from '../services/projectAnalyzer';
import { generateSampleAndroidZip } from '../services/sampleProject';
import type { AndroidProjectMetadata, ExtractedFile } from '../types/project';

interface ZipUploaderProps {
  onProjectLoaded: (data: {
    metadata: AndroidProjectMetadata;
    files: ExtractedFile[];
    zipName: string;
  }) => void;
  isAnalyzing: boolean;
  setIsAnalyzing: (analyzing: boolean) => void;
}

export const ZipUploader: React.FC<ZipUploaderProps> = ({
  onProjectLoaded,
  isAnalyzing,
  setIsAnalyzing,
}) => {
  const [dragOver, setDragOver] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploadStatus, setUploadStatus] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleProcessFile = async (file: File | Blob, fileName: string) => {
    setError(null);
    setIsAnalyzing(true);
    setUploadStatus('Scanning ZIP archive & verifying path safety...');

    try {
      const result = await analyzeAndroidZip(file);
      setUploadStatus('Android project validated successfully!');
      onProjectLoaded({
        metadata: result.metadata,
        files: result.files,
        zipName: fileName,
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setError(msg);
    } finally {
      setIsAnalyzing(false);
      setUploadStatus(null);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleProcessFile(file, file.name);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      if (!file.name.toLowerCase().endsWith('.zip')) {
        setError('Please drop a valid .zip file containing your Android Studio project.');
        return;
      }
      handleProcessFile(file, file.name);
    }
  };

  const handleLoadSample = async () => {
    setError(null);
    setIsAnalyzing(true);
    setUploadStatus('Generating valid Kotlin Android Compose sample project...');

    try {
      const blob = await generateSampleAndroidZip();
      await handleProcessFile(blob, 'SGQuickSampleApp.zip');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setError(`Failed to generate sample project: ${msg}`);
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="w-full">
      <input
        ref={fileInputRef}
        type="file"
        accept=".zip,application/zip"
        onChange={handleFileInputChange}
        className="hidden"
      />

      {/* Main Upload Box */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        onClick={() => !isAnalyzing && fileInputRef.current?.click()}
        className={`group relative border-2 border-dashed rounded-3xl p-6 sm:p-10 text-center cursor-pointer transition-all ${
          dragOver
            ? 'border-emerald-400 bg-emerald-500/10'
            : 'border-slate-700/80 hover:border-emerald-500/60 bg-slate-900/50 hover:bg-slate-900/80'
        } ${isAnalyzing ? 'pointer-events-none opacity-80' : ''}`}
      >
        <div className="max-w-md mx-auto space-y-4">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 group-hover:scale-105 transition-transform">
            {isAnalyzing ? (
              <FileArchive className="w-8 h-8 animate-bounce text-emerald-400" />
            ) : (
              <UploadCloud className="w-8 h-8 text-emerald-400" />
            )}
          </div>

          <div>
            <h3 className="text-lg sm:text-xl font-bold text-white">
              {isAnalyzing ? 'Analyzing Android Project...' : 'Select Android Project ZIP'}
            </h3>
            <p className="mt-1 text-xs sm:text-sm text-slate-400">
              Tap to browse your Android phone storage or drag & drop a ZIP archive
            </p>
          </div>

          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-800/80 border border-slate-700/80 text-xs text-slate-300">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Path traversal & zip bomb protected</span>
          </div>

          {uploadStatus && (
            <div className="text-xs text-emerald-400 font-medium animate-pulse">
              {uploadStatus}
            </div>
          )}
        </div>
      </div>

      {error && (
        <div className="mt-4 flex items-start gap-3 p-4 rounded-2xl bg-red-950/40 border border-red-800/60 text-red-200 text-xs sm:text-sm">
          <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <span className="font-semibold text-red-300">Project Validation Failed</span>
            <p className="text-red-400 leading-relaxed">{error}</p>
          </div>
        </div>
      )}

      {/* Instant Sample Starter Option */}
      <div className="mt-4 p-4 rounded-2xl bg-slate-900/60 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-left">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs sm:text-sm font-semibold text-slate-200">
              Don't have a ZIP ready on your phone?
            </div>
            <div className="text-[11px] sm:text-xs text-slate-400">
              Load our pre-configured Kotlin Android starter to test cloud compilation right now.
            </div>
          </div>
        </div>

        <button
          onClick={(e) => {
            e.stopPropagation();
            handleLoadSample();
          }}
          disabled={isAnalyzing}
          className="w-full sm:w-auto px-4 py-2 text-xs font-semibold text-cyan-300 bg-cyan-950/60 hover:bg-cyan-900/60 border border-cyan-800/60 rounded-xl transition-colors whitespace-nowrap shrink-0 flex items-center justify-center gap-1.5"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Load Sample Android Project</span>
        </button>
      </div>
    </div>
  );
};
