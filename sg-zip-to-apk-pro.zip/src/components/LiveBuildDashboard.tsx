import React, { useEffect, useRef, useState } from 'react';
import {
  ExternalLink,
  Terminal,
  Clock,
  CheckCircle2,
  XCircle,
  Loader2,
  AlertTriangle,
  RotateCcw,
  Download,
  Share2,
  Maximize2,
  Minimize2,
} from 'lucide-react';
import { getJobLogs, getRunJobs, getWorkflowRun } from '../services/githubApi';
import type { GitHubJob, GitHubWorkflowRun } from '../types/github';
import type { BuildStatus } from '../types/project';

interface LiveBuildDashboardProps {
  token: string;
  owner: string;
  repo: string;
  runId: number;
  projectName: string;
  applicationId: string;
  variant: string;
  onBuildComplete: (status: 'SUCCESS' | 'FAILED', durationSeconds: number) => void;
  onCancelOrReset: () => void;
}

export const LiveBuildDashboard: React.FC<LiveBuildDashboardProps> = ({
  token,
  owner,
  repo,
  runId,
  projectName,
  applicationId,
  variant,
  onBuildComplete,
  onCancelOrReset,
}) => {
  const [workflowRun, setWorkflowRun] = useState<GitHubWorkflowRun | null>(null);
  const [jobs, setJobs] = useState<GitHubJob[]>([]);
  const [logs, setLogs] = useState<string>('Initializing build monitoring...');
  const [status, setStatus] = useState<BuildStatus>('WAITING');
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const [isLogExpanded, setIsLogExpanded] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const pollIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const logContainerRef = useRef<HTMLDivElement>(null);
  const startTimeRef = useRef<number>(Date.now());
  const hasFinishedRef = useRef<boolean>(false);

  // Live tabular timer
  useEffect(() => {
    startTimeRef.current = Date.now();
    timerRef.current = setInterval(() => {
      if (!hasFinishedRef.current) {
        setElapsedSeconds(Math.floor((Date.now() - startTimeRef.current) / 1000));
      }
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  // Poll GitHub Actions API for real run status, jobs, and steps
  useEffect(() => {
    let isMounted = true;

    const poll = async () => {
      try {
        const run = await getWorkflowRun(token, owner, repo, runId);
        if (!isMounted) return;
        setWorkflowRun(run);

        // Map status: WAITING -> QUEUED -> BUILDING -> SUCCESS / FAILED
        if (run.status === 'queued') {
          setStatus('QUEUED');
        } else if (run.status === 'in_progress') {
          setStatus('BUILDING');
        } else if (run.status === 'completed') {
          if (run.conclusion === 'success') {
            setStatus('SUCCESS');
          } else {
            setStatus('FAILED');
          }
        }

        // Fetch jobs & steps
        const runJobs = await getRunJobs(token, owner, repo, runId);
        if (!isMounted) return;
        setJobs(runJobs);

        // Fetch logs for the primary build job
        if (runJobs.length > 0) {
          const mainJob = runJobs[0];
          try {
            const rawLogs = await getJobLogs(token, owner, repo, mainJob.id);
            if (isMounted && rawLogs) {
              setLogs(rawLogs);
            }
          } catch {
            // Logs might not be ready yet
          }
        }

        // Check completion
        if (run.status === 'completed' && !hasFinishedRef.current) {
          hasFinishedRef.current = true;
          const duration = Math.floor((Date.now() - startTimeRef.current) / 1000);
          if (run.conclusion === 'success') {
            onBuildComplete('SUCCESS', duration);
          } else {
            setErrorMessage(
              'Gradle compilation failed in GitHub Actions. Check terminal logs below for compilation stacktrace.'
            );
            onBuildComplete('FAILED', duration);
          }
        }
      } catch (err: unknown) {
        console.error('Error polling GitHub Actions:', err);
      }
    };

    poll();
    pollIntervalRef.current = setInterval(poll, 4000); // Poll every 4s

    return () => {
      isMounted = false;
      if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
    };
  }, [token, owner, repo, runId, onBuildComplete]);

  // Auto-scroll logs
  useEffect(() => {
    if (logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [logs]);

  const formatDuration = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const steps = jobs[0]?.steps || [];

  return (
    <div className="w-full space-y-6">
      {/* Top Status Card */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 sm:p-6 shadow-xl space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <span>{owner}/{repo}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono">#{workflowRun?.run_number || 1}</span>
              <span aria-hidden="true">·</span>
              <span className="capitalize">{variant} Variant</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white mt-1">
              {projectName}
            </h2>
            <div className="text-xs font-mono text-emerald-400">{applicationId}</div>
          </div>

          <div className="flex items-center gap-3">
            {workflowRun?.html_url && (
              <a
                href={workflowRun.html_url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 transition-colors"
              >
                <span>GitHub Run</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}
          </div>
        </div>

        {/* Status & Timer row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
            <span className="text-[11px] font-medium text-slate-400 block">Stage</span>
            <div className="mt-1 flex items-center gap-2">
              {status === 'BUILDING' && <Loader2 className="w-4 h-4 text-emerald-400 animate-spin" />}
              {status === 'QUEUED' && <Clock className="w-4 h-4 text-amber-400" />}
              {status === 'WAITING' && <Clock className="w-4 h-4 text-slate-400" />}
              {status === 'SUCCESS' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
              {status === 'FAILED' && <XCircle className="w-4 h-4 text-red-400" />}
              <span
                className={`text-sm sm:text-base font-bold font-mono ${
                  status === 'SUCCESS'
                    ? 'text-emerald-400'
                    : status === 'FAILED'
                    ? 'text-red-400'
                    : status === 'BUILDING'
                    ? 'text-emerald-400'
                    : 'text-amber-400'
                }`}
              >
                {status}
              </span>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
            <span className="text-[11px] font-medium text-slate-400 block">Elapsed Time</span>
            <div className="mt-1 text-base sm:text-lg font-bold font-mono tabular-nums text-slate-100 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-slate-500" />
              <span>{formatDuration(elapsedSeconds)}</span>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
            <span className="text-[11px] font-medium text-slate-400 block">Cloud Runner</span>
            <div className="mt-1 text-xs sm:text-sm font-semibold text-slate-200">
              ubuntu-latest
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
            <span className="text-[11px] font-medium text-slate-400 block">Completed Steps</span>
            <div className="mt-1 text-base sm:text-lg font-bold font-mono tabular-nums text-slate-100">
              {steps.filter((s) => s.conclusion === 'success').length} / {steps.length || 7}
            </div>
          </div>
        </div>

        {/* Detailed Job Steps Checklist */}
        {steps.length > 0 && (
          <div className="space-y-2 pt-2">
            <span className="text-xs font-semibold text-slate-300 block">Workflow Steps</span>
            <div className="space-y-1.5">
              {steps.map((step, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/40 border border-slate-800/60 text-xs"
                >
                  <div className="flex items-center gap-2.5">
                    {step.conclusion === 'success' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : step.conclusion === 'failure' ? (
                      <XCircle className="w-4 h-4 text-red-400 shrink-0" />
                    ) : step.status === 'in_progress' ? (
                      <Loader2 className="w-4 h-4 text-emerald-400 animate-spin shrink-0" />
                    ) : (
                      <div className="w-4 h-4 rounded-full border border-slate-700 shrink-0" />
                    )}
                    <span
                      className={`${
                        step.status === 'in_progress'
                          ? 'font-bold text-white'
                          : step.conclusion === 'success'
                          ? 'text-slate-200'
                          : 'text-slate-400'
                      }`}
                    >
                      {step.name}
                    </span>
                  </div>
                  <span className="text-[11px] font-mono text-slate-500 capitalize">
                    {step.status === 'in_progress' ? 'Running...' : step.conclusion || step.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {errorMessage && (
          <div className="flex items-start gap-3 p-4 rounded-2xl bg-red-950/40 border border-red-800/60 text-red-200 text-xs sm:text-sm">
            <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <span className="font-semibold text-red-300">Build Failure Detected</span>
              <p className="text-red-400">{errorMessage}</p>
            </div>
          </div>
        )}
      </div>

      {/* Live Terminal Log Streamer */}
      <div
        className={`rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden shadow-2xl transition-all ${
          isLogExpanded ? 'fixed inset-4 z-50 flex flex-col' : ''
        }`}
      >
        <div className="flex items-center justify-between px-4 py-3 bg-slate-900 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-semibold text-slate-200">Real-Time Cloud Build Logs</span>
            {status === 'BUILDING' && (
              <span className="text-[10px] text-emerald-400 animate-pulse font-mono">● LIVE</span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsLogExpanded(!isLogExpanded)}
              className="p-1 text-slate-400 hover:text-slate-200 rounded-lg hover:bg-slate-800"
              title={isLogExpanded ? 'Minimize logs' : 'Expand full-screen'}
            >
              {isLogExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
          </div>
        </div>

        <div
          ref={logContainerRef}
          className={`p-4 font-mono text-[11px] sm:text-xs text-slate-300 overflow-auto custom-scrollbar whitespace-pre-wrap leading-relaxed ${
            isLogExpanded ? 'flex-1' : 'max-h-[380px]'
          }`}
        >
          {logs}
        </div>
      </div>
    </div>
  );
};
