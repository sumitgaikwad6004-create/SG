import React from 'react';
import {
  Layers,
  Cpu,
  FileCode2,
  FolderTree,
  AlertTriangle,
  CheckCircle2,
  Code,
  RotateCcw,
} from 'lucide-react';
import type { AndroidProjectMetadata } from '../types/project';

interface ProjectAnalysisCardProps {
  metadata: AndroidProjectMetadata;
  zipName: string;
  onReset: () => void;
  onPreviewWorkflow: () => void;
}

export const ProjectAnalysisCard: React.FC<ProjectAnalysisCardProps> = ({
  metadata,
  zipName,
  onReset,
  onPreviewWorkflow,
}) => {
  return (
    <div className="w-full rounded-2xl bg-slate-900 border border-slate-800 p-5 sm:p-6 shadow-xl space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span>Archive: {zipName}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">{metadata.totalFiles} files</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">
              {(metadata.totalSize / (1024 * 1024)).toFixed(2)} MB
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white mt-1">
            {metadata.projectName}
          </h2>
          <div className="text-xs font-mono text-emerald-400 mt-0.5">
            {metadata.applicationId}
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onPreviewWorkflow}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl transition-colors"
          >
            <Code className="w-3.5 h-3.5 text-emerald-400" />
            <span>Workflow Code</span>
          </button>
          <button
            onClick={onReset}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-xl transition-colors"
            title="Upload a different project"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Change</span>
          </button>
        </div>
      </div>

      {/* Grid of detected technical specs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
          <span className="text-[11px] font-medium text-slate-400 block">Android SDK</span>
          <div className="mt-1 flex items-baseline gap-1 text-slate-100 font-mono">
            <span className="text-base sm:text-lg font-bold">API {metadata.targetSdk}</span>
            <span className="text-xs text-slate-500">(Min {metadata.minSdk})</span>
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
          <span className="text-[11px] font-medium text-slate-400 block">Gradle Version</span>
          <div className="mt-1 text-base sm:text-lg font-bold text-slate-100 font-mono">
            v{metadata.gradleVersion || '8.5'}
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
          <span className="text-[11px] font-medium text-slate-400 block">Android Plugin (AGP)</span>
          <div className="mt-1 text-base sm:text-lg font-bold text-slate-100 font-mono truncate">
            v{metadata.agpVersion || '8.2.2'}
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
          <span className="text-[11px] font-medium text-slate-400 block">Cloud Runner JDK</span>
          <div className="mt-1 flex items-baseline gap-1.5 text-emerald-400 font-mono font-bold">
            <span className="text-base sm:text-lg">Java {metadata.recommendedJavaVersion}</span>
            <span className="text-[10px] text-emerald-500/80 font-sans">Temurin</span>
          </div>
        </div>
      </div>

      {/* Modules & Structure Checklist */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Module breakdown */}
        <div className="p-4 rounded-xl bg-slate-950/40 border border-slate-800 space-y-2">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
            <Layers className="w-4 h-4 text-emerald-400" />
            <span>Detected Modules ({metadata.modules.length})</span>
          </div>
          <div className="flex flex-wrap gap-1.5 pt-1">
            {metadata.modules.map((m) => (
              <span
                key={m}
                className="px-2.5 py-1 text-xs font-mono bg-slate-800 border border-slate-700 rounded-lg text-slate-200"
              >
                :{m}
              </span>
            ))}
          </div>
        </div>

        {/* Verification Checklist */}
        <div className="p-4 rounded-xl bg-slate-950/40 border border-slate-800 space-y-2">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
            <FileCode2 className="w-4 h-4 text-emerald-400" />
            <span>Key Build Files Verification</span>
          </div>
          <div className="grid grid-cols-2 gap-y-1.5 gap-x-3 text-[11px] font-mono text-slate-300 pt-1">
            <div className="flex items-center gap-1.5">
              <CheckCircle2
                className={`w-3.5 h-3.5 shrink-0 ${
                  metadata.buildFilesFound.settingsGradle ? 'text-emerald-400' : 'text-slate-600'
                }`}
              />
              <span>settings.gradle</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2
                className={`w-3.5 h-3.5 shrink-0 ${
                  metadata.buildFilesFound.rootBuildGradle ? 'text-emerald-400' : 'text-slate-600'
                }`}
              />
              <span>build.gradle</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2
                className={`w-3.5 h-3.5 shrink-0 ${
                  metadata.hasGradleWrapper ? 'text-emerald-400' : 'text-amber-400'
                }`}
              />
              <span>gradlew {metadata.hasGradleWrapper ? '' : '(auto-fix)'}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2
                className={`w-3.5 h-3.5 shrink-0 ${
                  metadata.buildFilesFound.androidManifest ? 'text-emerald-400' : 'text-slate-600'
                }`}
              />
              <span>AndroidManifest</span>
            </div>
          </div>
        </div>
      </div>

      {/* Warnings if any */}
      {metadata.warnings.length > 0 && (
        <div className="p-3.5 rounded-xl bg-amber-950/30 border border-amber-800/50 space-y-1.5 text-xs text-amber-200">
          <div className="flex items-center gap-2 font-semibold text-amber-300">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>Compatibility Notice</span>
          </div>
          <ul className="list-disc list-inside space-y-0.5 text-amber-300/90 pl-1">
            {metadata.warnings.map((w, idx) => (
              <li key={idx}>{w}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};
