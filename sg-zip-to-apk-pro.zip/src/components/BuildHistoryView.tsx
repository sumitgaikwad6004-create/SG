import React, { useState } from 'react';
import {
  History,
  CheckCircle2,
  XCircle,
  Clock,
  ExternalLink,
  Trash2,
  Search,
  RotateCcw,
  Download,
  Package,
} from 'lucide-react';
import type { BuildRecord } from '../types/project';

interface BuildHistoryViewProps {
  history: BuildRecord[];
  onSelectBuildForRebuild: (record: BuildRecord) => void;
  onDeleteRecord: (id: string) => void;
  onClearHistory: () => void;
}

export const BuildHistoryView: React.FC<BuildHistoryViewProps> = ({
  history,
  onSelectBuildForRebuild,
  onDeleteRecord,
  onClearHistory,
}) => {
  const [filter, setFilter] = useState<'ALL' | 'SUCCESS' | 'FAILED'>('ALL');
  const [search, setSearch] = useState('');

  const filteredHistory = history.filter((item) => {
    if (filter === 'SUCCESS' && item.status !== 'SUCCESS') return false;
    if (filter === 'FAILED' && item.status !== 'FAILED') return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        item.projectName.toLowerCase().includes(q) ||
        item.repoName.toLowerCase().includes(q) ||
        item.applicationId.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="w-full space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white">Compilation History</h2>
          <p className="text-xs text-slate-400">
            Saved builds executed in your GitHub Actions cloud environment
          </p>
        </div>

        {history.length > 0 && (
          <button
            onClick={onClearHistory}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-red-400 hover:text-red-300 hover:bg-red-950/40 rounded-xl transition-colors self-start sm:self-auto"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear History</span>
          </button>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex items-center gap-1 p-1 bg-slate-900 rounded-xl border border-slate-800">
          <button
            onClick={() => setFilter('ALL')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
              filter === 'ALL'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All ({history.length})
          </button>
          <button
            onClick={() => setFilter('SUCCESS')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
              filter === 'SUCCESS'
                ? 'bg-slate-800 text-emerald-400 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Success ({history.filter((h) => h.status === 'SUCCESS').length})
          </button>
          <button
            onClick={() => setFilter('FAILED')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
              filter === 'FAILED'
                ? 'bg-slate-800 text-red-400 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Failed ({history.filter((h) => h.status === 'FAILED').length})
          </button>
        </div>

        <div className="relative">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search projects or repos..."
            className="w-full sm:w-64 bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
          />
        </div>
      </div>

      {/* History List */}
      {filteredHistory.length === 0 ? (
        <div className="p-12 text-center rounded-2xl bg-slate-900/50 border border-slate-800 text-slate-400 space-y-2">
          <History className="w-8 h-8 mx-auto text-slate-600" />
          <p className="text-sm">No compilation records match your criteria.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredHistory.map((item) => (
            <div
              key={item.id}
              className="p-4 sm:p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <span className="font-mono">{item.repoOwner}/{item.repoName}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono">Build #{item.buildNumber}</span>
                  <span aria-hidden="true">·</span>
                  <span className="capitalize">{item.buildVariant}</span>
                  <span aria-hidden="true">·</span>
                  <span>{new Date(item.startTime).toLocaleDateString()}</span>
                </div>

                <div className="flex items-center gap-2.5">
                  {item.status === 'SUCCESS' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : item.status === 'FAILED' ? (
                    <XCircle className="w-4 h-4 text-red-400 shrink-0" />
                  ) : (
                    <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                  )}
                  <h3 className="text-base font-bold text-white">{item.projectName}</h3>
                  <span className="text-xs font-mono text-slate-400">{item.applicationId}</span>
                </div>

                {item.apkName && item.status === 'SUCCESS' && (
                  <div className="flex items-center gap-2 text-xs text-emerald-400 font-mono pt-0.5">
                    <Package className="w-3.5 h-3.5" />
                    <span>{item.apkName}</span>
                    {item.apkSize && (
                      <span className="text-slate-500">
                        ({(item.apkSize / (1024 * 1024)).toFixed(2)} MB)
                      </span>
                    )}
                    {item.durationSeconds && (
                      <span className="text-slate-500">
                        · {Math.floor(item.durationSeconds / 60)}m {item.durationSeconds % 60}s
                      </span>
                    )}
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
                {item.htmlUrl && (
                  <a
                    href={item.htmlUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 text-slate-400 hover:text-slate-200 rounded-lg hover:bg-slate-800 transition-colors"
                    title="View GitHub Actions Run"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                )}

                <button
                  onClick={() => onSelectBuildForRebuild(item)}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 transition-colors"
                  title="Rebuild this project"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Rebuild</span>
                </button>

                <button
                  onClick={() => onDeleteRecord(item.id)}
                  className="p-2 text-slate-500 hover:text-red-400 rounded-lg hover:bg-slate-800 transition-colors"
                  title="Delete record"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
