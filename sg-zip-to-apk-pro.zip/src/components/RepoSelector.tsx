import React, { useEffect, useState } from 'react';
import {
  GitBranch,
  Plus,
  FolderGit2,
  Lock,
  Globe,
  KeyRound,
  Play,
  RefreshCw,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { createRepository, listUserRepositories } from '../services/githubApi';
import type { GitHubRepo, GitHubUser } from '../types/github';
import type { BuildVariant, SigningConfig } from '../types/project';

interface RepoSelectorProps {
  token: string | null;
  currentUser: GitHubUser | null;
  onOpenConnectModal: () => void;
  onStartBuild: (config: {
    repoOwner: string;
    repoName: string;
    branch: string;
    variant: BuildVariant;
    signingConfig?: SigningConfig;
  }) => void;
  isUploading: boolean;
  uploadProgress: { stage: string; current: number; total: number } | null;
  defaultProjectName: string;
}

export const RepoSelector: React.FC<RepoSelectorProps> = ({
  token,
  currentUser,
  onOpenConnectModal,
  onStartBuild,
  isUploading,
  uploadProgress,
  defaultProjectName,
}) => {
  const [repos, setRepos] = useState<GitHubRepo[]>([]);
  const [selectedRepoFullName, setSelectedRepoFullName] = useState<string>('');
  const [isLoadingRepos, setIsLoadingRepos] = useState(false);
  const [repoTab, setRepoTab] = useState<'create' | 'existing'>('create');

  // New Repo Form
  const [newRepoName, setNewRepoName] = useState(
    defaultProjectName.toLowerCase().replace(/[^a-z0-9_-]/g, '-') || 'my-android-app'
  );
  const [isPrivate, setIsPrivate] = useState(true);
  const [isCreatingRepo, setIsCreatingRepo] = useState(false);
  const [repoError, setRepoError] = useState<string | null>(null);

  // Build Options
  const [branch, setBranch] = useState('main');
  const [variant, setVariant] = useState<BuildVariant>('debug');

  // Signing Keystore (for release)
  const [showSigning, setShowSigning] = useState(false);
  const [signingConfig, setSigningConfig] = useState<SigningConfig>({
    keystoreBase64: '',
    storePassword: '',
    keyAlias: '',
    keyPassword: '',
  });

  // Fetch repos if token exists
  const fetchRepos = async () => {
    if (!token) return;
    setIsLoadingRepos(true);
    setRepoError(null);
    try {
      const data = await listUserRepositories(token);
      setRepos(data);
      if (data.length > 0 && !selectedRepoFullName) {
        setSelectedRepoFullName(data[0].full_name);
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setRepoError(`Could not load repositories: ${msg}`);
    } finally {
      setIsLoadingRepos(false);
    }
  };

  useEffect(() => {
    if (token) {
      fetchRepos();
    }
  }, [token]);

  // Handle Keystore File Input
  const handleKeystoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        const base64 = result.split(',')[1] || result;
        setSigningConfig((prev) => ({ ...prev, keystoreBase64: base64 }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !currentUser) {
      onOpenConnectModal();
      return;
    }

    setRepoError(null);

    let targetOwner = currentUser.login;
    let targetRepoName = '';

    if (repoTab === 'create') {
      const sanitizedName = newRepoName.trim().replace(/\s+/g, '-');
      if (!sanitizedName) {
        setRepoError('Please specify a repository name.');
        return;
      }

      setIsCreatingRepo(true);
      try {
        const created = await createRepository(
          token,
          sanitizedName,
          isPrivate,
          'Android project repository created by SG ZIP TO APK PRO'
        );
        targetOwner = created.full_name.split('/')[0];
        targetRepoName = created.name;
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : String(err);
        setRepoError(`Repository creation failed: ${msg}`);
        setIsCreatingRepo(false);
        return;
      } finally {
        setIsCreatingRepo(false);
      }
    } else {
      if (!selectedRepoFullName) {
        setRepoError('Please select a repository from the list.');
        return;
      }
      const parts = selectedRepoFullName.split('/');
      targetOwner = parts[0];
      targetRepoName = parts[1];
    }

    onStartBuild({
      repoOwner: targetOwner,
      repoName: targetRepoName,
      branch: branch.trim() || 'main',
      variant,
      signingConfig: variant === 'release' && signingConfig.keystoreBase64 ? signingConfig : undefined,
    });
  };

  return (
    <div className="w-full rounded-2xl bg-slate-900 border border-slate-800 p-5 sm:p-6 shadow-xl space-y-6">
      <div className="flex items-center justify-between pb-4 border-b border-slate-800">
        <div>
          <h3 className="text-lg font-bold text-white">Cloud Compilation Setup</h3>
          <p className="text-xs text-slate-400">Configure GitHub target repository and build variant</p>
        </div>

        {!token && (
          <button
            onClick={onOpenConnectModal}
            className="px-3 py-1.5 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-xl transition-colors"
          >
            Connect GitHub
          </button>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Repo Mode Segmented Tabs */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-2">
            Target GitHub Repository
          </label>
          <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-xl border border-slate-800">
            <button
              type="button"
              onClick={() => setRepoTab('create')}
              className={`flex-1 py-2 text-xs font-medium rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                repoTab === 'create'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create New Repository</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setRepoTab('existing');
                if (token && repos.length === 0) fetchRepos();
              }}
              className={`flex-1 py-2 text-xs font-medium rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                repoTab === 'existing'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <FolderGit2 className="w-3.5 h-3.5" />
              <span>Use Existing Repository</span>
            </button>
          </div>
        </div>

        {/* Tab 1: Create New Repo */}
        {repoTab === 'create' && (
          <div className="space-y-3 p-4 rounded-xl bg-slate-950/50 border border-slate-800/80">
            <div>
              <label className="block text-[11px] font-medium text-slate-400 mb-1">
                Repository Name
              </label>
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500 font-mono">
                  {currentUser?.login || 'username'}/
                </span>
                <input
                  type="text"
                  value={newRepoName}
                  onChange={(e) => setNewRepoName(e.target.value)}
                  placeholder="my-android-app"
                  className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-slate-100 focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-1">
              <span className="text-xs text-slate-300">Visibility</span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsPrivate(true)}
                  className={`flex items-center gap-1 px-3 py-1.5 text-xs rounded-lg border transition-colors ${
                    isPrivate
                      ? 'bg-emerald-950/50 border-emerald-600/80 text-emerald-300'
                      : 'bg-slate-900 border-slate-700 text-slate-400'
                  }`}
                >
                  <Lock className="w-3 h-3" />
                  <span>Private</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsPrivate(false)}
                  className={`flex items-center gap-1 px-3 py-1.5 text-xs rounded-lg border transition-colors ${
                    !isPrivate
                      ? 'bg-emerald-950/50 border-emerald-600/80 text-emerald-300'
                      : 'bg-slate-900 border-slate-700 text-slate-400'
                  }`}
                >
                  <Globe className="w-3 h-3" />
                  <span>Public</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Existing Repo */}
        {repoTab === 'existing' && (
          <div className="space-y-3 p-4 rounded-xl bg-slate-950/50 border border-slate-800/80">
            <div className="flex items-center justify-between">
              <label className="block text-[11px] font-medium text-slate-400">
                Select from your repositories
              </label>
              <button
                type="button"
                onClick={fetchRepos}
                disabled={isLoadingRepos}
                className="text-xs text-emerald-400 hover:text-emerald-300 flex items-center gap-1"
              >
                <RefreshCw className={`w-3 h-3 ${isLoadingRepos ? 'animate-spin' : ''}`} />
                <span>Refresh</span>
              </button>
            </div>

            {repos.length > 0 ? (
              <select
                value={selectedRepoFullName}
                onChange={(e) => setSelectedRepoFullName(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-slate-100 focus:outline-none focus:border-emerald-500"
              >
                {repos.map((r) => (
                  <option key={r.id} value={r.full_name}>
                    {r.full_name} {r.private ? '(Private)' : '(Public)'}
                  </option>
                ))}
              </select>
            ) : (
              <div className="text-xs text-slate-400 py-2">
                {isLoadingRepos ? 'Loading your repositories...' : 'No repositories found.'}
              </div>
            )}
          </div>
        )}

        {/* Branch & Build Variant */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Git Branch
            </label>
            <div className="relative">
              <input
                type="text"
                value={branch}
                onChange={(e) => setBranch(e.target.value)}
                placeholder="main"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-8 pr-3 py-2 text-xs font-mono text-slate-100 focus:outline-none focus:border-emerald-500"
              />
              <GitBranch className="w-4 h-4 text-slate-500 absolute left-2.5 top-2.5" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Build Variant
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setVariant('debug')}
                className={`py-2 text-xs font-medium rounded-xl border text-center transition-colors ${
                  variant === 'debug'
                    ? 'bg-emerald-950/60 border-emerald-500 text-emerald-300 font-semibold'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                Debug APK
              </button>
              <button
                type="button"
                onClick={() => setVariant('release')}
                className={`py-2 text-xs font-medium rounded-xl border text-center transition-colors ${
                  variant === 'release'
                    ? 'bg-emerald-950/60 border-emerald-500 text-emerald-300 font-semibold'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                Release APK
              </button>
            </div>
          </div>
        </div>

        {/* Release Signing Drawer */}
        {variant === 'release' && (
          <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-4 space-y-3">
            <button
              type="button"
              onClick={() => setShowSigning(!showSigning)}
              className="w-full flex items-center justify-between text-xs font-semibold text-slate-300"
            >
              <div className="flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-emerald-400" />
                <span>Keystore Signing Credentials (Optional)</span>
              </div>
              {showSigning ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            {showSigning && (
              <div className="pt-2 space-y-3 text-xs">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">
                    Upload .keystore or .jks file
                  </label>
                  <input
                    type="file"
                    accept=".keystore,.jks"
                    onChange={handleKeystoreFile}
                    className="w-full text-xs text-slate-400 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-slate-800 file:text-slate-200 hover:file:bg-slate-700"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Store Password</label>
                    <input
                      type="password"
                      value={signingConfig.storePassword}
                      onChange={(e) =>
                        setSigningConfig({ ...signingConfig, storePassword: e.target.value })
                      }
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-100"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Key Alias</label>
                    <input
                      type="text"
                      value={signingConfig.keyAlias}
                      onChange={(e) =>
                        setSigningConfig({ ...signingConfig, keyAlias: e.target.value })
                      }
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-100"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Key Password</label>
                    <input
                      type="password"
                      value={signingConfig.keyPassword}
                      onChange={(e) =>
                        setSigningConfig({ ...signingConfig, keyPassword: e.target.value })
                      }
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-100"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {repoError && (
          <div className="p-3 rounded-xl bg-red-950/40 border border-red-800/60 text-red-300 text-xs">
            {repoError}
          </div>
        )}

        {/* Upload progress indicator */}
        {isUploading && uploadProgress && (
          <div className="space-y-2 p-3.5 rounded-xl bg-emerald-950/20 border border-emerald-800/40">
            <div className="flex items-center justify-between text-xs text-emerald-300">
              <span>{uploadProgress.stage}...</span>
              <span className="font-mono tabular-nums">
                {uploadProgress.current} / {uploadProgress.total}
              </span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-emerald-400 h-full transition-all duration-200"
                style={{
                  width: `${Math.round((uploadProgress.current / uploadProgress.total) * 100)}%`,
                }}
              />
            </div>
          </div>
        )}

        {/* Primary Action Button */}
        <button
          type="submit"
          disabled={isUploading || isCreatingRepo}
          className="w-full py-3.5 px-6 rounded-xl font-bold text-sm text-slate-950 bg-emerald-400 hover:bg-emerald-300 disabled:opacity-50 transition-all shadow-lg shadow-emerald-950/30 flex items-center justify-center gap-2 active:scale-[0.99]"
        >
          {isUploading ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>Uploading Source & Workflow...</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-current" />
              <span>BUILD APK IN GITHUB CLOUD</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
};
