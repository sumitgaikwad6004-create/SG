import React, { useState } from 'react';
import { ExternalLink, Key, Lock, CheckCircle2, AlertCircle, X, ShieldCheck } from 'lucide-react';
import { getAuthenticatedUser, getRateLimit, setStoredGitHubToken } from '../services/githubApi';
import type { GitHubUser } from '../types/github';

interface GitHubConnectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConnected: (user: GitHubUser, token: string) => void;
}

export const GitHubConnectModal: React.FC<GitHubConnectModalProps> = ({
  isOpen,
  onClose,
  onConnected,
}) => {
  const [tokenInput, setTokenInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleConnect = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tokenInput.trim()) {
      setError('Please enter your GitHub Personal Access Token.');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const user = await getAuthenticatedUser(tokenInput.trim());
      const rateLimit = await getRateLimit(tokenInput.trim());

      setStoredGitHubToken(tokenInput.trim());
      onConnected(user, tokenInput.trim());
      onClose();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : String(err);
      setError(
        message.includes('401')
          ? 'Invalid or expired GitHub token. Please verify the token and try again.'
          : `Connection error: ${message}`
      );
    } finally {
      setIsLoading(false);
    }
  };

  const tokenCreationUrl =
    'https://github.com/settings/tokens/new?scopes=repo,workflow&description=SG+ZIP+TO+APK+PRO';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-800 p-5 sm:p-6 shadow-2xl text-slate-100 my-auto">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Key className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold">Connect GitHub Account</h2>
              <p className="text-xs text-slate-400">Required for GitHub Actions cloud compilation</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-200 rounded-lg hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleConnect} className="mt-4 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Personal Access Token (Classic or Fine-Grained)
            </label>
            <div className="relative">
              <input
                type="password"
                value={tokenInput}
                onChange={(e) => setTokenInput(e.target.value)}
                placeholder="ghp_... or github_pat_..."
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm font-mono text-slate-100 placeholder-slate-600 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                autoComplete="off"
                spellCheck="false"
              />
              <Lock className="w-4 h-4 text-slate-500 absolute right-3.5 top-3.5 pointer-events-none" />
            </div>
          </div>

          {error && (
            <div className="flex items-start gap-2.5 p-3 rounded-xl bg-red-950/40 border border-red-800/60 text-red-300 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Quick Token Generator Link */}
          <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800/90 space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-300">Need a GitHub Token?</span>
              <a
                href={tokenCreationUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-emerald-400 hover:text-emerald-300 font-medium"
              >
                <span>Generate Token in 1 Tap</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
            <p className="text-slate-400 leading-relaxed">
              Clicking the link pre-selects the only two required permissions:
            </p>
            <div className="space-y-1 text-slate-300 font-mono text-[11px]">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>repo</span>
                <span className="text-slate-500 font-sans text-xs">— To commit Android source files</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>workflow</span>
                <span className="text-slate-500 font-sans text-xs">— To trigger cloud compilation</span>
              </div>
            </div>
          </div>

          <div className="flex items-start gap-2 text-[11px] text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span>
              Your token is stored exclusively in your local browser storage and communicated directly to GitHub's official API. It is never transmitted to any third-party server.
            </span>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="px-5 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 disabled:opacity-50 rounded-xl transition-colors shadow-sm flex items-center gap-2"
            >
              {isLoading ? 'Verifying...' : 'Authenticate & Save'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
