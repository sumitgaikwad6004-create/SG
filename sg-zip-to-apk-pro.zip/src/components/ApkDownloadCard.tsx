import React, { useState } from 'react';
import {
  Download,
  Share2,
  CheckCircle2,
  Smartphone,
  ExternalLink,
  RotateCcw,
  Package,
  HardDrive,
  Sparkles,
} from 'lucide-react';
import { downloadApkFromProxy } from '../services/githubApi';
import type { GitHubArtifact } from '../types/github';

interface ApkDownloadCardProps {
  token: string;
  owner: string;
  repo: string;
  artifact: GitHubArtifact | null;
  projectName: string;
  applicationId: string;
  versionName?: string;
  versionCode?: number;
  durationSeconds: number;
  onRebuild: () => void;
}

export const ApkDownloadCard: React.FC<ApkDownloadCardProps> = ({
  token,
  owner,
  repo,
  artifact,
  projectName,
  applicationId,
  versionName,
  versionCode,
  durationSeconds,
  onRebuild,
}) => {
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadError, setDownloadError] = useState<string | null>(null);

  const apkFileName = `${projectName.toLowerCase().replace(/[^a-z0-9_-]/g, '-')}-debug.apk`;
  const formattedSize = artifact
    ? (artifact.size_in_bytes / (1024 * 1024)).toFixed(2) + ' MB'
    : 'Unknown size';

  const handleDownload = async () => {
    if (!artifact) return;
    setIsDownloading(true);
    setDownloadError(null);

    try {
      const blob = await downloadApkFromProxy(
        token,
        owner,
        repo,
        artifact.id,
        apkFileName
      );

      // Create download anchor for the mobile browser
      const blobUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = apkFileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(blobUrl), 10000);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setDownloadError(`Download failed: ${msg}. You can also download the ZIP artifact from GitHub.`);
    } finally {
      setIsDownloading(false);
    }
  };

  const handleShare = async () => {
    const title = `${projectName} APK`;
    const text = `Compiled Android APK for ${projectName} (${applicationId})`;
    const fallbackUrl = `https://github.com/${owner}/${repo}/actions`;

    if (navigator.share) {
      try {
        await navigator.share({
          title,
          text,
          url: fallbackUrl,
        });
      } catch {
        // User cancelled share
      }
    } else {
      await navigator.clipboard.writeText(fallbackUrl);
      alert('GitHub Actions run link copied to clipboard!');
    }
  };

  const formatDuration = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}m ${s}s`;
  };

  return (
    <div className="w-full rounded-3xl bg-emerald-950/20 border border-emerald-500/30 p-6 sm:p-8 shadow-2xl text-slate-100 space-y-6">
      {/* Success Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-emerald-800/40">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wide">
                Build Completed Successfully
              </span>
              <span aria-hidden="true" className="text-emerald-700">·</span>
              <span className="text-xs text-slate-400 font-mono">in {formatDuration(durationSeconds)}</span>
            </div>
            <h2 className="text-2xl font-bold text-white mt-0.5">{apkFileName}</h2>
          </div>
        </div>

        <button
          onClick={onRebuild}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 transition-colors shrink-0"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Rebuild Project</span>
        </button>
      </div>

      {/* APK Metadata Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
          <span className="text-[11px] text-slate-400 block">APK Size</span>
          <div className="mt-1 text-base sm:text-lg font-bold font-mono text-emerald-400">
            {formattedSize}
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
          <span className="text-[11px] text-slate-400 block">Application ID</span>
          <div className="mt-1 text-xs sm:text-sm font-semibold font-mono text-slate-200 truncate">
            {applicationId}
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
          <span className="text-[11px] text-slate-400 block">Version Info</span>
          <div className="mt-1 text-xs sm:text-sm font-semibold font-mono text-slate-200">
            {versionName || '1.0.0'} ({versionCode || 1})
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800">
          <span className="text-[11px] text-slate-400 block">Target Architecture</span>
          <div className="mt-1 text-xs sm:text-sm font-semibold text-slate-200">
            Universal (ARM64 / x86)
          </div>
        </div>
      </div>

      {downloadError && (
        <div className="p-3.5 rounded-xl bg-red-950/40 border border-red-800/60 text-red-300 text-xs">
          {downloadError}
        </div>
      )}

      {/* Primary Actions: Download directly to Phone Storage */}
      <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
        <button
          onClick={handleDownload}
          disabled={isDownloading || !artifact}
          className="w-full sm:flex-1 py-4 px-6 rounded-2xl font-bold text-sm text-slate-950 bg-emerald-400 hover:bg-emerald-300 disabled:opacity-50 transition-all shadow-xl shadow-emerald-950/40 flex items-center justify-center gap-2.5 active:scale-[0.99]"
        >
          <Download className="w-5 h-5" />
          <span>{isDownloading ? 'Extracting & Streaming APK...' : 'DOWNLOAD APK TO PHONE'}</span>
        </button>

        <button
          onClick={handleShare}
          className="w-full sm:w-auto py-4 px-5 rounded-2xl font-semibold text-xs text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 transition-colors flex items-center justify-center gap-2"
        >
          <Share2 className="w-4 h-4" />
          <span>Share</span>
        </button>
      </div>

      {/* Android Installation Tip */}
      <div className="flex items-start gap-3 p-4 rounded-2xl bg-slate-900/60 border border-slate-800 text-xs text-slate-300">
        <Smartphone className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
        <div>
          <span className="font-semibold text-white">Android Phone Installation:</span>
          <p className="text-slate-400 mt-0.5 leading-relaxed">
            Once downloaded, tap the notification or open your phone's <strong>Files / Downloads</strong> app and tap <strong>{apkFileName}</strong>. If prompted, allow <em>"Install unknown apps"</em> for your browser.
          </p>
        </div>
      </div>
    </div>
  );
};
