import React, { useEffect, useState } from 'react';
import { Navbar } from './components/Navbar';
import { ZipUploader } from './components/ZipUploader';
import { ProjectAnalysisCard } from './components/ProjectAnalysisCard';
import { RepoSelector } from './components/RepoSelector';
import { LiveBuildDashboard } from './components/LiveBuildDashboard';
import { ApkDownloadCard } from './components/ApkDownloadCard';
import { BuildHistoryView } from './components/BuildHistoryView';
import { AndroidGuideModal } from './components/AndroidGuideModal';
import { GitHubConnectModal } from './components/GitHubConnectModal';
import { WorkflowPreviewModal } from './components/WorkflowPreviewModal';
import {
  getAuthenticatedUser,
  getRunArtifacts,
  getStoredGitHubToken,
  getWorkflowRuns,
  setStoredGitHubToken,
  triggerWorkflowDispatch,
  uploadProjectFiles,
} from './services/githubApi';
import {
  generateBuildWorkflow,
  getStandardGradlewScript,
  getStandardGradleWrapperProperties,
} from './services/workflowGenerator';
import {
  clearBuildHistory,
  deleteBuildRecord,
  getBuildHistory,
  saveBuildRecord,
} from './services/historyStorage';
import type { GitHubArtifact, GitHubUser } from './types/github';
import type {
  AndroidProjectMetadata,
  BuildRecord,
  BuildVariant,
  ExtractedFile,
  SigningConfig,
} from './types/project';
import { Smartphone, Zap, Cloud, ShieldCheck } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'compiler' | 'history' | 'guide'>('compiler');
  const [isDark, setIsDark] = useState<boolean>(true);

  // GitHub Auth State
  const [token, setToken] = useState<string | null>(null);
  const [currentUser, setCurrentUser] = useState<GitHubUser | null>(null);
  const [isConnectModalOpen, setIsConnectModalOpen] = useState(false);

  // Project state
  const [loadedProject, setLoadedProject] = useState<{
    metadata: AndroidProjectMetadata;
    files: ExtractedFile[];
    zipName: string;
  } | null>(null);
  const [isAnalyzingZip, setIsAnalyzingZip] = useState(false);

  // Workflow preview
  const [isWorkflowPreviewOpen, setIsWorkflowPreviewOpen] = useState(false);

  // Compilation & Build tracking
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<{
    stage: string;
    current: number;
    total: number;
  } | null>(null);

  const [activeBuildRecord, setActiveBuildRecord] = useState<BuildRecord | null>(null);
  const [activeArtifact, setActiveArtifact] = useState<GitHubArtifact | null>(null);

  // History state
  const [history, setHistory] = useState<BuildRecord[]>([]);

  // Initialize theme & load cached token and history
  useEffect(() => {
    // Theme setup
    const savedTheme = localStorage.getItem('sg_theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const shouldBeDark = savedTheme ? savedTheme === 'dark' : prefersDark;
    setIsDark(shouldBeDark);
    if (shouldBeDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }

    // History setup
    setHistory(getBuildHistory());

    // Token setup
    const storedToken = getStoredGitHubToken();
    if (storedToken) {
      setToken(storedToken);
      getAuthenticatedUser(storedToken)
        .then((user) => setCurrentUser(user))
        .catch(() => {
          // Token expired or invalid
          setStoredGitHubToken(null);
          setToken(null);
        });
    }
  }, []);

  const handleToggleTheme = () => {
    const next = !isDark;
    setIsDark(next);
    localStorage.setItem('sg_theme', next ? 'dark' : 'light');
    if (next) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const handleDisconnect = () => {
    setStoredGitHubToken(null);
    setToken(null);
    setCurrentUser(null);
  };

  const handleConnected = (user: GitHubUser, validToken: string) => {
    setCurrentUser(user);
    setToken(validToken);
  };

  // Start cloud compilation
  const handleStartBuild = async (config: {
    repoOwner: string;
    repoName: string;
    branch: string;
    variant: BuildVariant;
    signingConfig?: SigningConfig;
  }) => {
    if (!loadedProject || !token) {
      setIsConnectModalOpen(true);
      return;
    }

    setIsUploading(true);
    setUploadProgress({ stage: 'Generating tailored workflow', current: 0, total: 100 });

    try {
      // 1. Generate workflow
      const workflowContent = generateBuildWorkflow(
        loadedProject.metadata,
        config.variant,
        config.signingConfig
      );

      // Ensure gradlew exists in files if missing
      const filesToUpload = [...loadedProject.files];
      if (!loadedProject.metadata.hasGradleWrapper) {
        filesToUpload.push({
          path: 'gradlew',
          isText: true,
          content: getStandardGradlewScript(),
          size: 150,
        });
        filesToUpload.push({
          path: 'gradle/wrapper/gradle-wrapper.properties',
          isText: true,
          content: getStandardGradleWrapperProperties(loadedProject.metadata.gradleVersion),
          size: 200,
        });
      }

      // 2. Upload source code & workflow atomically
      const { commitSha } = await uploadProjectFiles(
        token,
        config.repoOwner,
        config.repoName,
        config.branch,
        filesToUpload,
        workflowContent,
        (progress) => setUploadProgress(progress)
      );

      // 3. Trigger workflow dispatch
      setUploadProgress({ stage: 'Triggering GitHub Actions runner', current: 100, total: 100 });
      await triggerWorkflowDispatch(
        token,
        config.repoOwner,
        config.repoName,
        'build.yml',
        config.branch,
        { build_type: config.variant }
      );

      // 4. Poll for the newly created workflow run
      let runId = 0;
      let runNumber = 1;
      let htmlUrl = `https://github.com/${config.repoOwner}/${config.repoName}/actions`;

      // Wait up to 15 seconds for GitHub Actions to register the run
      for (let attempt = 0; attempt < 6; attempt++) {
        await new Promise((r) => setTimeout(r, 2500));
        try {
          const runs = await getWorkflowRuns(
            token,
            config.repoOwner,
            config.repoName,
            config.branch
          );
          if (runs.length > 0) {
            runId = runs[0].id;
            runNumber = runs[0].run_number;
            htmlUrl = runs[0].html_url;
            break;
          }
        } catch {
          // retry
        }
      }

      const newRecord: BuildRecord = {
        id: `build-${Date.now()}`,
        projectName: loadedProject.metadata.projectName,
        applicationId: loadedProject.metadata.applicationId,
        repoOwner: config.repoOwner,
        repoName: config.repoName,
        runId,
        buildNumber: runNumber,
        status: 'BUILDING',
        buildVariant: config.variant,
        startTime: new Date().toISOString(),
        commitSha,
        htmlUrl,
      };

      saveBuildRecord(newRecord);
      setHistory(getBuildHistory());
      setActiveBuildRecord(newRecord);
      setActiveArtifact(null);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      alert(`Compilation setup failed: ${msg}`);
    } finally {
      setIsUploading(false);
      setUploadProgress(null);
    }
  };

  const handleBuildComplete = async (status: 'SUCCESS' | 'FAILED', durationSeconds: number) => {
    if (!activeBuildRecord || !token) return;

    let artifactObj: GitHubArtifact | null = null;
    let apkName = `${activeBuildRecord.projectName.toLowerCase()}-${activeBuildRecord.buildVariant}.apk`;
    let apkSize = 0;
    let artifactId: number | undefined;

    if (status === 'SUCCESS' && activeBuildRecord.runId) {
      try {
        const artifacts = await getRunArtifacts(
          token,
          activeBuildRecord.repoOwner,
          activeBuildRecord.repoName,
          activeBuildRecord.runId
        );
        if (artifacts.length > 0) {
          artifactObj = artifacts[0];
          artifactId = artifactObj.id;
          apkSize = artifactObj.size_in_bytes;
          setActiveArtifact(artifactObj);
        }
      } catch (err) {
        console.error('Failed to query artifacts:', err);
      }
    }

    const updatedRecord: BuildRecord = {
      ...activeBuildRecord,
      status,
      durationSeconds,
      endTime: new Date().toISOString(),
      artifactId,
      apkName,
      apkSize,
    };

    saveBuildRecord(updatedRecord);
    setActiveBuildRecord(updatedRecord);
    setHistory(getBuildHistory());
  };

  const handleSelectBuildForRebuild = (record: BuildRecord) => {
    setActiveTab('compiler');
    setActiveBuildRecord(null);
    setActiveArtifact(null);
  };

  const handleDeleteRecord = (id: string) => {
    deleteBuildRecord(id);
    setHistory(getBuildHistory());
  };

  const handleClearHistory = () => {
    if (confirm('Are you sure you want to clear your build history?')) {
      clearBuildHistory();
      setHistory([]);
    }
  };

  const currentWorkflowContent = loadedProject
    ? generateBuildWorkflow(loadedProject.metadata, 'debug')
    : '';

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Top Bar matching contract */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentUser={currentUser}
        onOpenConnect={() => setIsConnectModalOpen(true)}
        onDisconnect={handleDisconnect}
        isDark={isDark}
        onToggleTheme={handleToggleTheme}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-8">
        {/* TAB 1: COMPILER */}
        {activeTab === 'compiler' && (
          <div className="space-y-6">
            {/* If currently monitoring a live build or completed build */}
            {activeBuildRecord && token ? (
              <div className="space-y-6">
                {activeBuildRecord.status === 'SUCCESS' && (
                  <ApkDownloadCard
                    token={token}
                    owner={activeBuildRecord.repoOwner}
                    repo={activeBuildRecord.repoName}
                    artifact={activeArtifact}
                    projectName={activeBuildRecord.projectName}
                    applicationId={activeBuildRecord.applicationId}
                    versionName={loadedProject?.metadata.versionName}
                    versionCode={loadedProject?.metadata.versionCode}
                    durationSeconds={activeBuildRecord.durationSeconds || 120}
                    onRebuild={() => {
                      setActiveBuildRecord(null);
                      setActiveArtifact(null);
                    }}
                  />
                )}

                <LiveBuildDashboard
                  token={token}
                  owner={activeBuildRecord.repoOwner}
                  repo={activeBuildRecord.repoName}
                  runId={activeBuildRecord.runId}
                  projectName={activeBuildRecord.projectName}
                  applicationId={activeBuildRecord.applicationId}
                  variant={activeBuildRecord.buildVariant}
                  onBuildComplete={handleBuildComplete}
                  onCancelOrReset={() => {
                    setActiveBuildRecord(null);
                    setActiveArtifact(null);
                  }}
                />
              </div>
            ) : (
              /* Compilation Workflow Steps */
              <div className="space-y-6">
                {/* Hero Feature Pill-free kicker */}
                <div className="text-center max-w-2xl mx-auto space-y-2 pt-2 pb-4">
                  <div className="flex items-center justify-center gap-2 text-xs text-slate-400">
                    <span>Android Studio Projects</span>
                    <span aria-hidden="true">·</span>
                    <span>GitHub Actions Cloud Runner</span>
                    <span aria-hidden="true">·</span>
                    <span>Zero PC Required</span>
                  </div>
                  <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white">
                    Convert Android ZIP to Installable APK
                  </h1>
                  <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto">
                    Upload your Android Studio ZIP from your phone, compile in GitHub Actions cloud runners, and download your installable APK directly to phone storage.
                  </p>
                </div>

                {/* Step 1: ZIP Upload or Sample */}
                {!loadedProject ? (
                  <ZipUploader
                    onProjectLoaded={(data) => setLoadedProject(data)}
                    isAnalyzing={isAnalyzingZip}
                    setIsAnalyzing={setIsAnalyzingZip}
                  />
                ) : (
                  /* Step 2 & 3: Project analysis + Repo Selector */
                  <div className="space-y-6">
                    <ProjectAnalysisCard
                      metadata={loadedProject.metadata}
                      zipName={loadedProject.zipName}
                      onReset={() => setLoadedProject(null)}
                      onPreviewWorkflow={() => setIsWorkflowPreviewOpen(true)}
                    />

                    <RepoSelector
                      token={token}
                      currentUser={currentUser}
                      onOpenConnectModal={() => setIsConnectModalOpen(true)}
                      onStartBuild={handleStartBuild}
                      isUploading={isUploading}
                      uploadProgress={uploadProgress}
                      defaultProjectName={loadedProject.metadata.projectName}
                    />
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* TAB 2: HISTORY */}
        {activeTab === 'history' && (
          <BuildHistoryView
            history={history}
            onSelectBuildForRebuild={handleSelectBuildForRebuild}
            onDeleteRecord={handleDeleteRecord}
            onClearHistory={handleClearHistory}
          />
        )}

        {/* TAB 3: ANDROID SETUP GUIDE */}
        {activeTab === 'guide' && <AndroidGuideModal />}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 py-6 text-center text-xs text-slate-500">
        <div className="max-w-5xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-300">SG ZIP TO APK PRO</span>
            <span aria-hidden="true">·</span>
            <span>Cloud Android Compiler</span>
          </div>
          <div>Ubuntu Latest Runners · Temurin OpenJDK · Android SDK</div>
        </div>
      </footer>

      {/* Modals */}
      <GitHubConnectModal
        isOpen={isConnectModalOpen}
        onClose={() => setIsConnectModalOpen(false)}
        onConnected={handleConnected}
      />

      <WorkflowPreviewModal
        isOpen={isWorkflowPreviewOpen}
        onClose={() => setIsWorkflowPreviewOpen(false)}
        workflowContent={currentWorkflowContent}
      />
    </div>
  );
}
