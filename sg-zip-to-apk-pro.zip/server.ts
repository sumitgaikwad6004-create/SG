import express, { Request, Response } from 'express';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import JSZip from 'jszip';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '50mb' }));

// Health check
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok', name: 'SG ZIP TO APK PRO Engine', time: new Date().toISOString() });
});

/**
 * Proxy and stream APK directly from GitHub Actions artifact.
 * GitHub Actions packages uploaded artifacts into a .zip file.
 * This endpoint downloads the artifact zip using the user's GitHub token,
 * extracts the real .apk inside, and streams the raw .apk directly to the
 * client phone with application/vnd.android.package-archive Content-Type.
 */
app.get('/api/download-apk', async (req: Request, res: Response) => {
  const { owner, repo, artifactId, apkName } = req.query;
  const authHeader = req.headers.authorization;

  if (!owner || !repo || !artifactId || !authHeader) {
    res.status(400).json({ error: 'Missing owner, repo, artifactId or Authorization header' });
    return;
  }

  try {
    const artifactUrl = `https://api.github.com/repos/${owner}/${repo}/actions/artifacts/${artifactId}/zip`;
    const response = await fetch(artifactUrl, {
      headers: {
        Authorization: authHeader,
        Accept: 'application/vnd.github+json',
        'User-Agent': 'SG-Zip-To-Apk-Pro',
      },
      redirect: 'follow',
    });

    if (!response.ok) {
      const errText = await response.text();
      res.status(response.status).json({
        error: `GitHub API error (${response.status}): ${errText || response.statusText}`,
      });
      return;
    }

    const arrayBuffer = await response.arrayBuffer();
    const zip = await JSZip.loadAsync(arrayBuffer);

    // Find the APK file inside the artifact ZIP
    let targetFile: JSZip.JSZipObject | null = null;
    let detectedApkName = (apkName as string) || 'app-debug.apk';

    for (const [relativePath, file] of Object.entries(zip.files)) {
      if (!file.dir && relativePath.toLowerCase().endsWith('.apk')) {
        targetFile = file;
        detectedApkName = path.basename(relativePath);
        break;
      }
    }

    if (!targetFile) {
      // Fallback: If no .apk found inside, return the zip archive itself
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="${repo}-artifacts.zip"`);
      res.send(Buffer.from(arrayBuffer));
      return;
    }

    const apkBuffer = await targetFile.async('nodebuffer');

    res.setHeader('Content-Type', 'application/vnd.android.package-archive');
    res.setHeader('Content-Disposition', `attachment; filename="${detectedApkName}"`);
    res.setHeader('Content-Length', apkBuffer.length);
    res.send(apkBuffer);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    console.error('Error streaming APK artifact:', message);
    res.status(500).json({ error: `Failed to extract and stream APK: ${message}` });
  }
});

// Vite middleware in dev or static files in production
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';
  const httpServer = http.createServer(app);

  if (isDev) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: {
          server: httpServer,
        },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`SG ZIP TO APK PRO server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Server startup error:', err);
  process.exit(1);
});
